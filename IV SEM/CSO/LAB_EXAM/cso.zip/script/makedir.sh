cd ../codes
mkdir q$1
cd q$1
touch q$1.c q$1.s
echo '#include<stdio.h>
typedef long long int ll;

int main() {

}' > q$1.c
echo '.global 
.text' > q$1.s
