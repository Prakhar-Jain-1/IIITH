#include<stdio.h>
typedef long long int ll;

void mundi(ll,char*,ll*);

int main() {
    ll n;
    scanf("%lld", &n);
    char arr[n];
    ll ret[n];
    for (int i = 0; i < n; i++){
        scanf("%c", arr + i);
    }
    mundi(n,arr, ret );
}
